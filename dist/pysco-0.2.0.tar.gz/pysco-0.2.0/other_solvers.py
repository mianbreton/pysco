import logging

import numpy as np
import numpy.typing as npt
import pandas as pd

import mesh
import utils


@utils.time_me
def fft(rhs: npt.NDArray[np.float32], param: pd.Series) -> npt.NDArray[np.float32]:
    """Compute FFT

    Parameters
    ----------
    rhs : npt.NDArray[np.float32]
        Right-hand side of Poisson Equation (density) [N_cells_1d, N_cells_1d,N_cells_1d]
    param : pd.Series
        Parameter container

    Returns
    -------
    npt.NDArray[np.float32]
        Potential [N_cells_1d, N_cells_1d,N_cells_1d]
    """
    # TODO: Rewrite with pyFFTW
    logging.debug("In fft")
    # TO DO: - Only compute invk2 once...
    # FFT
    rhs_fourier = np.fft.rfftn(rhs)
    # Divide by k**2
    n = 2 ** param["ncoarse"]
    k0 = 2.0 * np.pi * np.fft.rfftfreq(n, 1 / n)
    k1 = 2.0 * np.pi * np.fft.fftfreq(n, 1 / n)
    k2 = (
        k0[np.newaxis, np.newaxis, :] ** 2
        + k1[:, np.newaxis, np.newaxis] ** 2
        + k1[np.newaxis, :, np.newaxis] ** 2
    )
    invk2 = np.where(k2 == 0, 0, k2 ** (-1))
    potential_fourier = -rhs_fourier * invk2
    # Inverse FFT
    potential = np.fft.irfftn(potential_fourier).astype(np.float32)

    return potential


def conjugate_gradient(
    x: npt.NDArray[np.float32],
    rhs: npt.NDArray[np.float32],
    h: np.float32,
    param: pd.Series,
) -> npt.NDArray[np.float32]:
    """Compute Conjugate Gradient

    Parameters
    ----------
    x : npt.NDArray[np.float32]
        Potential (first guess) [N_cells_1d, N_cells_1d,N_cells_1d]
    rhs : npt.NDArray[np.float32]
        Right-hand side of Poisson Equation (density) [N_cells_1d, N_cells_1d,N_cells_1d]
    h : np.float32
        Grid size
    param : pd.Series
        Parameter container

    Returns
    -------
    npt.NDArray[np.float32]
        Potential [N_cells_1d, N_cells_1d,N_cells_1d]
    """
    logging.debug("In conjugate_gradient")
    Nmax = 1000
    ncells_1d = int(x.shape[0])
    # Run
    potential = x.ravel()
    r = mesh.residual(x, rhs, h).ravel()
    d = r
    rrold = np.dot(r, r)

    if (not "tolerance" in param) or (param["nsteps"] % 3) == 0:
        param["tolerance"] = param["epsrel"] * np.sqrt(rrold)

    for i in range(Nmax):
        Ad = mesh.laplacian(d.reshape(ncells_1d, ncells_1d, ncells_1d), h).ravel()
        alpha = rrold / np.dot(d, Ad)
        potential = potential + np.dot(alpha, d)
        # plt.imshow(potential.reshape(ncells_1d, ncells_1d, ncells_1d)[0])
        # plt.show()
        if (i != 0) and ((i % 50) == 0):
            r = mesh.residual(
                potential.reshape(ncells_1d, ncells_1d, ncells_1d), rhs, h
            ).ravel()
        else:
            r = r - np.dot(alpha, Ad)

        rrnew = np.dot(r, r)
        logging.debug(
            f"{i=} {np.sqrt(rrnew)=} {param['tolerance']=} Still within tolerance"
        )
        if np.sqrt(rrnew) < param["tolerance"]:
            logging.debug(f"{i} {np.sqrt(rrnew)=} {param['tolerance']}")
            break
        d = r + rrnew / rrold * d
        rrold = rrnew
    return potential.reshape(ncells_1d, ncells_1d, ncells_1d)


def steepest_descent(
    x: npt.NDArray[np.float32],
    rhs: npt.NDArray[np.float32],
    h: np.float32,
    param: pd.Series,
) -> npt.NDArray[np.float32]:
    """Compute Steepest descent

    Parameters
    ----------
    x : npt.NDArray[np.float32]
        Potential (first guess) [N_cells_1d, N_cells_1d,N_cells_1d]
    rhs : npt.NDArray[np.float32]
        Right-hand side of Poisson Equation (density) [N_cells_1d, N_cells_1d,N_cells_1d]
    h : np.float32
        Grid size
    param : pd.Series
        Parameter container

    Returns
    -------
    npt.NDArray[np.float32]
        Potential [N_cells_1d, N_cells_1d,N_cells_1d]
    """
    logging.debug("In steepest_descent")
    Nmax = 10000
    ncells_1d = int(x.shape[0])
    # Run
    potential = x.ravel()
    r = mesh.residual(x, rhs, h).ravel()
    rr = np.dot(np.transpose(r), r)

    if (not "tolerance" in param) or (param["nsteps"] % 3) == 0:
        param["tolerance"] = param["epsrel"] * np.sqrt(rr)

    for i in range(Nmax):
        Ar = mesh.laplacian(r.reshape(ncells_1d, ncells_1d, ncells_1d), h).ravel()
        alpha = rr / np.dot(np.transpose(r), Ar)
        potential = potential + np.dot(alpha, r)
        # plt.imshow(potential.reshape(ncells_1d, ncells_1d, ncells_1d)[0])
        # plt.show()
        if (i != 0) and ((i % 50) == 0):
            r = mesh.residual(
                potential.reshape(ncells_1d, ncells_1d, ncells_1d), rhs, h
            ).ravel()
        else:
            r = r - np.dot(alpha, Ar)

        rr = np.dot(np.transpose(r), r)
        logging.debug(
            f"{i=} {np.sqrt(rr)=} {param['tolerance']=} Still within tolerance"
        )
        if np.sqrt(rr) < param["tolerance"]:
            logging.debug(f"{i} {np.sqrt(rr)=} {param['tolerance']}")
            break
    return potential.reshape(ncells_1d, ncells_1d, ncells_1d)
