#!/bin/bash

rm __pycache__/*
